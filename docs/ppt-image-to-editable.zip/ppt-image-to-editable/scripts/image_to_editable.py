#!/usr/bin/env python3
"""位图 PPT 页 -> 文字可编辑 PPTX。

路径 A (默认): 擦字底图 + 原生文本框  —— 视觉≈100%, 全部文字可编辑
路径 B:        A + 主色块矢量化        —— 额外把"矩形度高"的大色块重画为原生矩形(实验性)
路径 C:        不擦字直接叠文本框      —— 快速版, 会有重影

用法:
  python image_to_editable.py --input p1.jpg p2.jpg --report-dir reports \
      --output out.pptx --mode A --font "微软雅黑"

说明:
  - 字号来自报告里的估算值(font_pt_est), 误差约 ±10-15%, 交付后需人工微调。
  - 字体无法从像素识别, 一律用 --font 指定的系统字体替代(默认 微软雅黑)。
  - 本脚本不做渲染校对(环境无 PowerPoint/LibreOffice), 自检请用 qa_preview.py。
"""
import argparse
import io
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
from lxml import etree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from probe_bitmap import probe, imread_unicode, SLIDE_W_IN, SLIDE_H_IN, EMU_PER_IN

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt


def hex_to_rgb(h):
    h = h.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def hex_to_bgr(h):
    h = h.lstrip("#")
    return (int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16))


def set_run_font(run, name):
    """同时设 latin 与 ea 字体, 确保中文生效。"""
    run.font.name = name
    rpr = run._r.get_or_add_rPr()
    for tag in ("a:latin", "a:ea"):
        el = rpr.find(qn(tag))
        if el is None:
            el = etree.SubElement(rpr, qn(tag))
        el.set("typeface", name)


def erase_text(img, texts, dilate=2):
    """用 OCR 四点多边形生成 mask 并 inpaint 擦除原文字。"""
    h, w = img.shape[:2]
    mask = np.zeros((h, w), np.uint8)
    n = 0
    for t in texts:
        quad = t.get("quad")
        if not quad:
            continue
        cv2.fillPoly(mask, [np.array(quad, dtype=np.int32)], 255)
        n += 1
    if n == 0:
        return img, 0
    if dilate > 0:
        mask = cv2.dilate(mask, np.ones((7, 7), np.uint8), iterations=dilate)
    return cv2.inpaint(img, mask, 5, cv2.INPAINT_TELEA), n


def vectorize_blocks(img, slide, prs, palette, tol=90, min_area=0.015, max_blocks=6):
    """把'矩形度高'的大色块用原生矩形重画(实验性: 不规则形状会被跳过)。"""
    h, w = img.shape[:2]
    made = 0
    for pc in palette:
        try:
            target = np.array(hex_to_bgr(pc["hex"]), dtype=np.int16)
        except (ValueError, IndexError):
            continue
        diff = np.abs(img.astype(np.int16) - target).sum(axis=2)
        mask = (diff < tol).astype(np.uint8) * 255
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:2]:
            area = cv2.contourArea(c)
            if area < w * h * min_area:
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            if area / float(max(1, bw * bh)) < 0.85:   # 不是矩形 → 跳过
                continue
            shp = slide.shapes.add_shape(
                MSO_SHAPE.RECTANGLE,
                Emu(int(x / w * prs.slide_width)), Emu(int(y / h * prs.slide_height)),
                Emu(int(bw / w * prs.slide_width)), Emu(int(bh / h * prs.slide_height)))
            shp.fill.solid()
            shp.fill.fore_color.rgb = hex_to_rgb(pc["hex"])
            shp.line.fill.background()
            made += 1
            if made >= max_blocks:
                return made
    return made


def build_slide(prs, img_path, rep, font_name, erase=True, dilate=2, vblocks=False):
    img = imread_unicode(img_path)
    h, w = img.shape[:2]
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    sw, sh = prs.slide_width, prs.slide_height
    texts = rep.get("texts", [])

    base = img
    erased_n = 0
    if erase and texts:
        base, erased_n = erase_text(img, texts, dilate=dilate)
    ok, buf = cv2.imencode(".png", base)
    slide.shapes.add_picture(io.BytesIO(buf.tobytes()), 0, 0, width=sw, height=sh)

    blocks = 0
    if vblocks:
        blocks = vectorize_blocks(img, slide, prs, rep.get("palette", []))

    made = 0
    for t in texts:
        x0, y0, bw, bh = t["bbox_px"]
        fs = max(6.0, float(t.get("font_pt_est") or 12.0))
        cy = (y0 + bh / 2.0) / h * sh
        tw = int(bw / float(w) * sw * 1.25) + int(Pt(8))
        th = int(max(bh / float(h) * sh * 1.8, fs * 1.6 * 12700))
        left = int(x0 / float(w) * sw) - int(Pt(2))
        top = int(cy - th / 2.0)
        tb = slide.shapes.add_textbox(Emu(left), Emu(top), Emu(tw), Emu(th))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = 0
        tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        run = p.add_run()
        run.text = t["text"]
        run.font.size = Pt(round(fs * 2) / 2.0)
        try:
            run.font.color.rgb = hex_to_rgb(t.get("color") or "#222222")
        except (ValueError, TypeError):
            run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
        set_run_font(run, font_name)
        made += 1
    return {"textboxes": made, "erased": erased_n, "blocks": blocks}


def load_items(rep, corr=None):
    """报告 + 修正表 -> 最终要绘制的元素列表。

    corr 结构(人工核对后填写, 可选):
      {"3": {"text": {"9": "订正后的文字"},
             "erase_ext": {"2": [x, y, w, h]},          # 擦除区扩展(补 OCR 漏项)
             "merge": [[25, 26, 27, "合并成一行"]]}}     # 一行被切碎时合并
    序号均为报告 texts 里的 1-based 序号。
    """
    corr = corr or {}
    texts = rep.get("texts", [])
    # JSON 里键都是字符串, 统一转回 int, 否则下标匹配不上
    text_corr = {(int(k) if str(k).isdigit() else k): v
                 for k, v in (corr.get("text") or {}).items()}
    ext_corr = {(int(k) if str(k).isdigit() else k): v
                for k, v in (corr.get("erase_ext") or {}).items()}
    skip, items = set(), []
    for grp in corr.get("merge", []):
        idxs, newtext = grp[:-1], grp[-1]
        ms = [texts[i - 1] for i in idxs]
        x0 = min(m["bbox_px"][0] for m in ms)
        y0 = min(m["bbox_px"][1] for m in ms)
        x1 = max(m["bbox_px"][0] + m["bbox_px"][2] for m in ms)
        y1 = max(m["bbox_px"][1] + m["bbox_px"][3] for m in ms)
        items.append({
            "bbox_px": [x0, y0, x1 - x0, y1 - y0],
            "quad": [[x0, y0], [x1, y0], [x1, y1], [x0, y1]],
            "text": newtext,
            "font_pt_est": max(float(m.get("font_pt_est") or 12) for m in ms),
            "color": ms[0].get("color"),
        })
        skip.update(idxs)
    for i, t in enumerate(texts, 1):
        if i in skip:
            continue
        it = dict(t)
        if i in text_corr:
            it["text"] = text_corr[i]
        if i in ext_corr:
            x, y, w, h = ext_corr[i]
            it["bbox_px"] = [x, y, w, h]
            it["quad"] = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]]
        items.append(it)
    return items


def add_textboxes(slide, prs, items, img_w, img_h, font_name):
    """按测量坐标叠加原生文本框。"""
    sw, sh = prs.slide_width, prs.slide_height
    made = 0
    for t in items:
        x0, y0, bw, bh = t["bbox_px"]
        fs = max(6.0, float(t.get("font_pt_est") or 12.0))
        cy = (y0 + bh / 2.0) / img_h * sh
        tw = int(bw / float(img_w) * sw * 1.25) + int(Pt(8))
        th = int(max(bh / float(img_h) * sh * 1.6, fs * 1.6 * 12700))
        left = max(0, int(x0 / float(img_w) * sw) - int(Pt(2)))
        top = int(cy - th / 2.0)
        tb = slide.shapes.add_textbox(Emu(left), Emu(top), Emu(tw), Emu(th))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = 0
        tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        run = p.add_run()
        run.text = t["text"]
        run.font.size = Pt(round(fs * 2) / 2.0)
        try:
            run.font.color.rgb = hex_to_rgb(t.get("color") or "#222222")
        except (ValueError, TypeError):
            run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
        set_run_font(run, font_name)
        made += 1
    return made


_IMG_EXT = (".jpeg", ".jpg", ".png", ".bmp", ".tif", ".tiff")


def replace_in_pptx(pptx_path, image_dir, out_path, font_name="微软雅黑",
                    report_dir=None, corrections=None, mode="A", dilate=2):
    """原地模式: 把已有 PPTX 里的"整页图片页"转成可编辑(其余页原样保留)。

    约定: image_dir 下 p01.jpeg / p02.png ... 对应第 1 / 2 ... 页(零填充两位)。
    只处理"该页恰好有 1 张整页图片"的页; 其它页完全不动。
    做法: 擦字后**替换该图片的图像部件 blob**(而不新建演示文稿), 再叠加原生文本框。
    """
    erase = mode in ("A", "B")
    corr_all = corrections or {}
    prs = Presentation(pptx_path)
    done = []
    for idx, slide in enumerate(prs.slides):
        page = idx + 1
        stem = "p%02d" % page
        img_path = None
        for ext in _IMG_EXT:
            cand = os.path.join(image_dir, stem + ext)
            if os.path.exists(cand):
                img_path = cand
                break
        if img_path is None:
            continue
        pics = [sh for sh in slide.shapes if sh.shape_type == 13]
        if len(pics) != 1 or len(slide.shapes) != 1:
            print("  P%02d 跳过(该页不是『单张整页图』)" % page)
            continue
        rep = None
        if report_dir:
            rp = os.path.join(report_dir, stem + ".json")
            if os.path.exists(rp):
                with open(rp, encoding="utf-8") as f:
                    rep = json.load(f)
        if rep is None:
            rep = probe(img_path)
        corr = corr_all.get(str(page), corr_all.get(page, {}))
        items = load_items(rep, corr)
        img = imread_unicode(img_path)
        ih, iw = img.shape[:2]
        base, erased_n = erase_text(img, items, dilate=dilate) if erase else (img, 0)
        # 替换图像部件(编码与部件扩展名一致)
        pic = pics[0]
        part = slide.part.related_part(pic._element.blip_rId)
        pname = str(part.partname).lower()
        if pname.endswith(".png"):
            ok, buf = cv2.imencode(".png", base)
        else:
            ok, buf = cv2.imencode(".jpg", base, [int(cv2.IMWRITE_JPEG_QUALITY), 94])
        part._blob = buf.tobytes()
        made = add_textboxes(slide, prs, items, iw, ih, font_name)
        done.append({"page": page, "textboxes": made, "erased": erased_n})
        print("  P%02d 底图已替换 | textboxes=%-3d erased=%-3d" % (page, made, erased_n))
    prs.save(out_path)
    print("saved: %s | 处理页数=%d | 总文本框=%d | 总页数=%d(未改)"
          % (out_path, len(done), sum(d["textboxes"] for d in done),
             len(prs.slides._sldIdLst)))
    return done


def main():
    ap = argparse.ArgumentParser(description="位图 PPT 页 -> 文字可编辑 PPTX")
    ap.add_argument("--input", nargs="*", help="一张或多张图片(新建模式)")
    ap.add_argument("--output", required=True, help="输出 .pptx")
    ap.add_argument("--report-dir", default=None, help="测量报告目录(每图 <stem>.json); 无则现场探测")
    ap.add_argument("--mode", default="A", choices=["A", "B", "C"],
                    help="A=擦字+叠字(默认) B=A+色块矢量化 C=不擦字(有重影)")
    ap.add_argument("--font", default="微软雅黑", help="替代字体(原字体无法识别)")
    ap.add_argument("--dilate", type=int, default=2, help="擦字 mask 膨胀次数")
    # --- 原地模式 ---
    ap.add_argument("--replace-in", default=None,
                    help="原地模式: 已有 PPTX 路径; 仅转换其中的『整页图片页』, 其余页原样保留")
    ap.add_argument("--image-dir", default=None,
                    help="原地模式: 图片目录, 约定 p01/p02… 对应第 1/2… 页")
    ap.add_argument("--corrections", default=None,
                    help="修正表 JSON(人工核对后订正文字/合并碎行/扩展擦除区)")
    args = ap.parse_args()

    if args.replace_in:
        if not args.image_dir:
            ap.error("原地模式需要 --image-dir")
        corr = None
        if args.corrections and os.path.exists(args.corrections):
            with open(args.corrections, encoding="utf-8") as f:
                corr = json.load(f)
        replace_in_pptx(args.replace_in, args.image_dir, args.output, args.font,
                        args.report_dir, corr, args.mode, args.dilate)
        return

    erase = args.mode in ("A", "B")
    vblocks = args.mode == "B"
    prs = Presentation()
    prs.slide_width = Emu(int(SLIDE_W_IN * EMU_PER_IN))
    prs.slide_height = Emu(int(SLIDE_H_IN * EMU_PER_IN))

    tot_text = tot_erase = tot_blocks = 0
    for path in args.input:
        stem = Path(path).stem
        rep = None
        if args.report_dir:
            rp = os.path.join(args.report_dir, stem + ".json")
            if os.path.exists(rp):
                with open(rp, encoding="utf-8") as f:
                    rep = json.load(f)
        if rep is None:
            rep = probe(path)
        info = build_slide(prs, path, rep, args.font,
                           erase=erase, dilate=args.dilate, vblocks=vblocks)
        tot_text += info["textboxes"]
        tot_erase += info["erased"]
        tot_blocks += info["blocks"]
        print("  %-28s -> textboxes=%-3d erased=%-3d blocks=%d"
              % (stem, info["textboxes"], info["erased"], info["blocks"]))

    prs.save(args.output)
    print("saved: %s | pages=%d textboxes=%d erased_regions=%d vector_blocks=%d"
          % (args.output, len(prs.slides._sldIdLst), tot_text, tot_erase, tot_blocks))
    print("NEXT: 用 qa_preview.py 做几何自检, 再在 PowerPoint 中人工核对"
          "(字体为替代字体, 字号为估算值)。")


if __name__ == "__main__":
    main()
