#!/usr/bin/env python3
"""近似渲染自检: 用"底图 + 按真实坐标重绘文字"合成预览, 并与原图并排输出。

为什么需要它:
  本环境没有 PowerPoint / LibreOffice, 无法真正把 PPTX 渲染成图, 因此拿不到
  像素级校对。本脚本用 PIL 按**真实文本框坐标/字号/颜色**把文字重画到底图上,
  得到一张"近似渲染图", 与原图上下并排 —— 这是离线环境下最接近"渲染对比"的手段。

能看出什么:
  - 文字有没有错位、溢出、被遮挡
  - 取色是否与原文一致(发白/发灰一眼可见)
  - 字号是否明显偏大/偏小
  - 擦字底图是否干净(残留的原字会与重绘文字重影)

看不出什么:
  - 字体本身(用系统字体替代)的差异
  - PowerPoint 的自动换行、行距、字距等引擎行为

用法:
  python sim_preview.py --input out.pptx --orig-dir pages/ --out-dir preview/
  python sim_preview.py --input out.pptx --out-dir preview/          # 不比对原图, 只出合成图
"""
import argparse
import io
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation

_FONT_CANDIDATES = (
    "C:/Windows/Fonts/msyh.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
)
_EXT = (".jpeg", ".jpg", ".png", ".bmp")


def _font(fpx):
    for p in _FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, max(8, int(fpx)))
            except Exception:
                continue
    return ImageFont.load_default()


def _pic_blob(slide):
    for sh in slide.shapes:
        if sh.shape_type == 13:
            return sh.image.blob
    return None


def render_slide(slide, sw, prev_w=1600):
    """把一页合成成 PIL 图: 底图(若为图片页) + 按坐标重绘的文字。"""
    blob = _pic_blob(slide)
    if blob:
        base = Image.open(io.BytesIO(blob)).convert("RGB")
        h = int(base.size[1] * prev_w / base.size[0])
        canvas = base.resize((prev_w, h), Image.LANCZOS)
    else:
        h = int(prev_w * 0.5625)
        canvas = Image.new("RGB", (prev_w, h), (255, 255, 255))
    scale = prev_w / float(sw)
    px_per_pt = prev_w / (sw / 914400.0) / 72.0
    dr = ImageDraw.Draw(canvas)
    for sh in slide.shapes:
        if not sh.has_text_frame or not sh.text_frame.text.strip():
            continue
        runs = sh.text_frame.paragraphs[0].runs
        if not runs:
            continue
        r0 = runs[0]
        size = r0.font.size.pt if r0.font.size else 12.0
        col = (34, 34, 34)
        try:
            if r0.font.color and r0.font.color.rgb:
                c = str(r0.font.color.rgb)
                col = (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16))
        except Exception:
            pass
        x, y = int(sh.left * scale), int(sh.top * scale)
        w, hh = int(sh.width * scale), int(sh.height * scale)
        f = _font(round(size * px_per_pt))
        txt = sh.text_frame.text
        bb = dr.textbbox((0, 0), txt, font=f)
        ty = y + (hh - (bb[3] - bb[1])) // 2 - bb[1]
        dr.text((x, ty), txt, font=f, fill=col)
    return canvas


def main():
    ap = argparse.ArgumentParser(description="近似渲染自检(底图 + 重绘文字)")
    ap.add_argument("--input", required=True, help="生成的 .pptx")
    ap.add_argument("--orig-dir", default=None,
                    help="原图目录(p01.jpeg/p02.png…), 有则上下并排比对")
    ap.add_argument("--out-dir", required=True, help="输出目录")
    ap.add_argument("--width", type=int, default=1600, help="每页宽度(px)")
    ap.add_argument("--pages", default=None, help="只处理这些页, 如 1,3,6")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    only = None
    if args.pages:
        only = {int(x) for x in args.pages.split(",") if x.strip().isdigit()}

    prs = Presentation(args.input)
    sw = prs.slide_width
    made = 0
    for idx, slide in enumerate(prs.slides, 1):
        if only and idx not in only:
            continue
        sim = render_slide(slide, sw, args.width)
        orig_path = None
        if args.orig_dir:
            for ext in _EXT:
                cand = os.path.join(args.orig_dir, "p%02d%s" % (idx, ext))
                if os.path.exists(cand):
                    orig_path = cand
                    break
        if orig_path:
            orig = Image.open(orig_path).convert("RGB")
            orig = orig.resize((args.width, sim.size[1]), Image.LANCZOS)
            sep = Image.new("RGB", (args.width, 22), (255, 210, 90))
            sheet = Image.new("RGB", (args.width, sim.size[1] * 2 + 22), (255, 255, 255))
            sheet.paste(orig, (0, 0))                       # 上: 原图
            sheet.paste(sep, (0, sim.size[1]))
            sheet.paste(sim, (0, sim.size[1] + 22))         # 下: 近似渲染
        else:
            sheet = sim
        p = os.path.join(args.out_dir, "sim%02d.png" % idx)
        sheet.save(p)
        made += 1
        print("  P%02d -> %s" % (idx, os.path.basename(p)))
    print("wrote %d preview(s) -> %s" % (made, args.out_dir))
    print("注意: 这是近似渲染(PIL 重绘), 字体为替代字体; 最终仍需在 PowerPoint 中人工核对。")


if __name__ == "__main__":
    main()
