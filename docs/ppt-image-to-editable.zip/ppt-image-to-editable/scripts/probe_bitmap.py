#!/usr/bin/env python3
"""PPT 位图页探针: 配色采样 + OCR 文字提取 + 位置/字号估算 -> 测量报告 JSON。

用法:
  python probe_bitmap.py --input page.jpg --out-report report.json
  python probe_bitmap.py --input page.jpg --no-ocr        # 只测配色

说明:
  - OpenCV 读不了中文路径, 统一走 np.fromfile + imdecode。
  - 字号估算: 优先按"墨迹宽度 ÷ 字符 advance 之和"反推(CJK advance 恒为 1em, 与字体无关,
    实测误差约 3-5%); 宽度不可用时退回"墨迹高 ÷ 1.10"。整体误差约 ±10%。
    (早期版本用"墨迹高 ÷ 0.72", 实测偏大约 47%, 已废弃。)
  - 颜色用 kmeans(k=2) 分离"背景簇"与"文字笔画簇", 取少数簇为文字色。
"""
import argparse
import colorsys
import json

import cv2
import numpy as np

SLIDE_W_IN = 13.333   # 16:9 标准宽
SLIDE_H_IN = 7.5
EMU_PER_IN = 914400

# 字宽表(单位 em, 实测自微软雅黑 Regular, 1000px 渲染)。CJK/全角标点/箭头恒为 1em,
# 与字体无关, 故"墨迹宽度 ÷ advance 之和"是可靠的字号反推口径。
_ASCII_ADV = {
    " ": 0.30, "!": 0.31, '"': 0.44, "#": 0.64, "$": 0.59, "%": 0.89, "&": 0.87,
    "'": 0.26, "(": 0.33, ")": 0.33, "*": 0.46, "+": 0.74, ",": 0.24, "-": 0.43,
    ".": 0.24, "/": 0.43, ":": 0.24, ";": 0.24, "<": 0.74, "=": 0.74, ">": 0.74,
    "?": 0.48, "@": 1.03, "[": 0.33, "\\": 0.42, "]": 0.33, "^": 0.74, "_": 0.45,
    "`": 0.29, "{": 0.33, "|": 0.27, "}": 0.33, "~": 0.74,
    "0": 0.59, "1": 0.59, "2": 0.59, "3": 0.59, "4": 0.59,
    "5": 0.59, "6": 0.59, "7": 0.59, "8": 0.59, "9": 0.59,
    "A": 0.70, "B": 0.63, "C": 0.67, "D": 0.76, "E": 0.55, "F": 0.53, "G": 0.74,
    "H": 0.77, "I": 0.29, "J": 0.40, "K": 0.64, "L": 0.51, "M": 0.98, "N": 0.81,
    "O": 0.81, "P": 0.61, "Q": 0.81, "R": 0.65, "S": 0.58, "T": 0.57, "U": 0.75,
    "V": 0.68, "W": 1.02, "X": 0.65, "Y": 0.60, "Z": 0.62,
    "a": 0.55, "b": 0.64, "c": 0.50, "d": 0.64, "e": 0.57, "f": 0.35, "g": 0.64,
    "h": 0.62, "i": 0.27, "j": 0.27, "k": 0.54, "l": 0.27, "m": 0.94, "n": 0.62,
    "o": 0.64, "p": 0.64, "q": 0.64, "r": 0.38, "s": 0.46, "t": 0.37, "u": 0.62,
    "v": 0.53, "w": 0.79, "x": 0.51, "y": 0.53, "z": 0.49,
}
FALLBACK_HEIGHT_COEF = 1.10   # 拉丁为主文本: 墨迹高 ≈ 字号 × 1.10 (实测 1.07~1.13)


def _adv(ch):
    """单字符 advance(em)。"""
    o = ord(ch)
    if o < 128:
        return _ASCII_ADV.get(ch, 0.45)
    if (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0xF900 <= o <= 0xFAFF
            or 0x3000 <= o <= 0x303F or 0xFF00 <= o <= 0xFFEF or 0x2190 <= o <= 0x21FF):
        return 1.00          # CJK / CJK 标点 / 全角 / 箭头: 恒为 1em
    return 0.85


def est_font_px(text, bw, bh):
    """估算字号(px) -> (值, 所用方法)。

    优先"墨迹宽度 ÷ advance 之和" —— CJK 字符 advance 恒为 1em(与字体无关),
    实测误差约 3-5%, 明显优于按高度反推; 宽度不可用(过短/异常)时退回高度法。
    注: 早期版本用"墨迹高 ÷ 0.72", 实测偏大约 47%, 已废弃。
    """
    adv = sum(_adv(c) for c in text) if text else 0.0
    if adv >= 1.5:
        est = bw / adv
        if 0.35 * bh <= est <= 3.2 * bh:      # 合理性护栏
            return est, "width"
    return bh / FALLBACK_HEIGHT_COEF, "height"


def is_risky(t):
    """判断是否为需人工复核的项。

    OCR 对短文本(数字编号/两字词)置信度天然偏低, 但往往识别正确;
    阈值按文本长度分档, 避免把"01""材料"这类正确结果全部误报。
    真正的风险是"漏项"——漏掉的文字不会出现在结果里, 只能靠人工对照原图发现。
    """
    n = len(t.get("text", ""))
    thr = 0.50 if n <= 2 else (0.62 if n <= 4 else 0.70)
    return t.get("conf", -1) < thr


def imread_unicode(path):
    """读图(兼容中文路径)。"""
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise SystemExit("ERROR: 无法读取图片: %s" % path)
    return img


def sample_palette(img, max_side=360, min_share=0.004):
    """按色相分桶采样配色, 跳过低饱和背景。"""
    h, w = img.shape[:2]
    scale = max_side / float(max(w, h))
    small = cv2.resize(img, (max(1, int(w * scale)), max(1, int(h * scale))))
    rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB).reshape(-1, 3)
    buckets = {}
    for r, g, b in rgb:
        hh, ss, vv = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
        if ss < 0.20:
            continue
        key = (int(hh * 36),
               0 if ss < 0.45 else (1 if ss < 0.75 else 2),
               0 if vv < 0.45 else (1 if vv < 0.72 else 2))
        buckets.setdefault(key, []).append((r, g, b))
    total = float(len(rgb)) or 1.0
    out = []
    for _, v in sorted(buckets.items(), key=lambda kv: -len(kv[1])):
        share = len(v) / total
        if share < min_share:
            continue
        m = np.mean(v, axis=0).astype(int)
        out.append({"hex": "#%02X%02X%02X" % tuple(m), "share": round(share, 4)})
    return out[:10]


def kmeans_text_color(img, box):
    """bbox 内 kmeans(k=2), 判定文字笔画色。

    不能简单取"少数簇"——当文字较粗或卡片有填充底块时, 笔画簇与底块簇的像素数会接近,
    实测 P3"事项散落" 深蓝笔画 4936 : 浅蓝底 4712, 取少数簇会误取到背景色。
    改为: 先用 bbox **外圈**像素估计背景, 再取"离背景更远"的那个簇。
    (白字压在深色块上同样成立: 外圈即色块, 更远的簇是白字。)
    """
    H, W = img.shape[:2]
    xs = [p[0] for p in box]
    ys = [p[1] for p in box]
    x0, y0 = max(0, int(min(xs))), max(0, int(min(ys)))
    x1, y1 = min(W, int(max(xs))), min(H, int(max(ys)))
    if x1 - x0 < 3 or y1 - y0 < 3:
        return None
    roi = img[y0:y1, x0:x1]
    z = roi.reshape(-1, 3).astype(np.float32)
    if len(z) < 20:
        return None

    # --- 背景估计: 扩展框减去 bbox 的外圈像素取中位数 ---
    pw = max(3, int((x1 - x0) * 0.30))
    ph = max(3, int((y1 - y0) * 0.50))
    ex0, ey0 = max(0, x0 - pw), max(0, y0 - ph)
    ex1, ey1 = min(W, x1 + pw), min(H, y1 + ph)
    big = img[ey0:ey1, ex0:ex1]
    m = np.ones(big.shape[:2], bool)
    m[y0 - ey0:y1 - ey0, x0 - ex0:x1 - ex0] = False
    bgpx = big[m].reshape(-1, 3)
    if len(bgpx) >= 8:
        bg = np.median(bgpx, axis=0)
    else:
        edge = np.concatenate([big[:2].reshape(-1, 3), big[-2:].reshape(-1, 3),
                               big[:, :2].reshape(-1, 3), big[:, -2:].reshape(-1, 3)])
        bg = np.median(edge, axis=0)

    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    try:
        _, labels, centers = cv2.kmeans(z, 2, None, crit, 3, cv2.KMEANS_PP_CENTERS)
    except cv2.error:
        return None
    cnt = np.bincount(labels.flatten(), minlength=2)
    d = [float(np.linalg.norm(centers[k] - bg)) for k in range(2)]
    if abs(d[0] - d[1]) < 12.0:
        pick = int(np.argmin(cnt))       # 两簇离背景都远 -> 退回少数簇
    else:
        pick = int(np.argmax(d))         # 离背景更远 = 文字笔画
    b, g, r = centers[pick].astype(int).tolist()
    return "#%02X%02X%02X" % (r, g, b)


def probe(path, use_ocr=True):
    img = imread_unicode(path)
    h, w = img.shape[:2]
    rep = {
        "source": path,
        "image": {"w_px": w, "h_px": h, "ratio": round(w / float(h), 4)},
        "target_slide": {
            "w_in": SLIDE_W_IN, "h_in": SLIDE_H_IN,
            "w_emu": int(SLIDE_W_IN * EMU_PER_IN),
            "h_emu": int(SLIDE_H_IN * EMU_PER_IN),
        },
        "palette": sample_palette(img),
        "texts": [],
        "low_conf": [],
        "ocr_error": None,
    }
    if not use_ocr:
        return rep
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError:
        rep["ocr_error"] = ("rapidocr-onnxruntime 未安装, 已跳过 OCR。"
                            "安装: pip install rapidocr-onnxruntime")
        return rep

    engine = RapidOCR()
    res, _ = engine(img)
    for item in (res or []):
        box, text, score = item[0], item[1], item[2]
        try:
            score = float(score)
        except (TypeError, ValueError):
            score = -1.0
        xs = [p[0] for p in box]
        ys = [p[1] for p in box]
        x0, y0 = min(xs), min(ys)
        x1, y1 = max(xs), max(ys)
        bw, bh = x1 - x0, y1 - y0
        font_px, method = est_font_px(text, bw, bh)   # 字宽反推(主) / 高度反推(备)
        font_pt = font_px / (w / SLIDE_W_IN) * 72.0
        rep["texts"].append({
            "text": text,
            "conf": round(score, 3),
            "bbox_px": [round(x0), round(y0), round(bw), round(bh)],
            "bbox_norm": [round(x0 / w, 4), round(y0 / h, 4),
                          round(bw / w, 4), round(bh / h, 4)],
            "font_px_est": round(font_px, 1),
            "font_pt_est": round(font_pt, 1),
            "font_method": method,
            "color": kmeans_text_color(img, box),
            "quad": [[round(float(p[0])), round(float(p[1]))] for p in box],
        })
    rep["texts"].sort(key=lambda t: (round(t["bbox_norm"][1], 2), t["bbox_norm"][0]))
    rep["low_conf"] = [t["text"] for t in rep["texts"] if is_risky(t)]
    return rep


def main():
    ap = argparse.ArgumentParser(description="PPT 位图页探针")
    ap.add_argument("--input", required=True, help="图片路径(JPG/PNG)")
    ap.add_argument("--out-report", default=None, help="测量报告 JSON 输出路径")
    ap.add_argument("--no-ocr", action="store_true", help="只采样配色, 跳过 OCR")
    args = ap.parse_args()

    rep = probe(args.input, use_ocr=not args.no_ocr)
    text = json.dumps(rep, ensure_ascii=False, indent=2)
    if args.out_report:
        with open(args.out_report, "w", encoding="utf-8") as f:
            f.write(text)
        print("report -> %s" % args.out_report)
    print("image %dx%d | palette=%d | texts=%d | low_conf=%d"
          % (rep["image"]["w_px"], rep["image"]["h_px"], len(rep["palette"]),
             len(rep["texts"]), len(rep["low_conf"])))
    if rep.get("ocr_error"):
        print("WARN: %s" % rep["ocr_error"])
    if rep["low_conf"]:
        print("建议复核(低置信, 不一定错): %s" % " | ".join(rep["low_conf"]))
    if rep["texts"]:
        print("提醒: OCR 会漏项, 漏掉的文字不会出现在结果里 —— 必须对照原图逐页核对。")


if __name__ == "__main__":
    main()
