#!/usr/bin/env python3
"""PPTX 几何示意图自检(非真实渲染)。

把每页的形状/文本框按真实坐标画成 PNG 示意图, 用于检查元素位置有无明显错位。
注意: 这是示意图, 看不见字体/渐变/装饰细节 —— 最终必须由用户在 PowerPoint 中核对。

用法:
  python qa_preview.py --input out.pptx --out-dir qa --grid 3
"""
import argparse
import math
import os

from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation

FONT_CANDIDATES = (
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
    "C:/Windows/Fonts/arial.ttf",
)


def load_font(size):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                pass
    return ImageFont.load_default()


def render_slide(slide, sw_emu, sh_emu, w=960, h=540):
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    sx, sy = w / float(sw_emu), h / float(sh_emu)
    f = load_font(11)
    for shp in slide.shapes:
        try:
            left = int(shp.left * sx)
            top = int(shp.top * sy)
            ww = int(shp.width * sx)
            hh = int(shp.height * sy)
        except (TypeError, ValueError):
            continue
        is_pic = False
        try:
            is_pic = int(shp.shape_type) == 13
        except (TypeError, ValueError):
            pass
        if is_pic:
            d.rectangle([left, top, left + ww, top + hh], fill=(230, 230, 230),
                        outline=(150, 150, 150))
            d.text((left + 4, top + 4), "[IMG 底图]", fill=(120, 120, 120), font=f)
        elif shp.has_text_frame and shp.text_frame.text.strip():
            d.rectangle([left, top, left + ww, top + hh], outline=(70, 130, 200))
            txt = shp.text_frame.text.strip().replace("\n", "/")[:26]
            d.text((left + 2, top + 2), txt, fill=(20, 40, 80), font=f)
        else:
            d.rectangle([left, top, left + ww, top + hh], outline=(205, 205, 205))
    return img


def main():
    ap = argparse.ArgumentParser(description="PPTX 几何示意图自检")
    ap.add_argument("--input", required=True, help="PPTX 路径")
    ap.add_argument("--out-dir", required=True, help="输出目录")
    ap.add_argument("--grid", type=int, default=3, help="总览拼图列数")
    args = ap.parse_args()

    prs = Presentation(args.input)
    os.makedirs(args.out_dir, exist_ok=True)
    sw, sh = prs.slide_width, prs.slide_height
    thumbs = []
    for i, slide in enumerate(prs.slides, 1):
        img = render_slide(slide, sw, sh)
        img.save(os.path.join(args.out_dir, "page_%02d.png" % i))
        thumbs.append(img)
    print("wrote %d page images -> %s" % (len(thumbs), args.out_dir))

    cols = max(1, args.grid)
    rows = int(math.ceil(len(thumbs) / float(cols)))
    cw, ch, gap = 480, 270, 10
    sheet = Image.new("RGB", (cols * cw + (cols + 1) * gap,
                              rows * ch + (rows + 1) * gap), (245, 245, 245))
    for idx, th in enumerate(thumbs):
        r, c = divmod(idx, cols)
        small = th.resize((cw, ch))
        sheet.paste(small, (gap + c * (cw + gap), gap + r * (ch + gap)))
    out = os.path.join(args.out_dir, "sheet_%dcol.png" % cols)
    sheet.save(out)
    print("overview -> %s" % out)
    print("注意: 这是几何示意图, 不是真实渲染; 最终请在 PowerPoint 中人工核对。")


if __name__ == "__main__":
    main()
